package com.zybooks.weighttrackingapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class WeightTrackerActivity extends Activity {

    private DatabaseWeightTracker db;
    private WeightAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_tracker);

        db = new DatabaseWeightTracker(this);

        RecyclerView recyclerView = findViewById(R.id.weightRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = db.getAllWeights();
        adapter = new WeightAdapter(this, cursor, db);
        recyclerView.setAdapter(adapter);
    }

    // display goal weight
    @Override
    protected void onStart() {
        super.onStart();
        double goalWeight = db.getGoalWeight();
        TextView goalWeightText = findViewById(R.id.goalWeightTextView);

        if (goalWeight != -1) {
            goalWeightText.setText(String.format("Goal Weight: %s", goalWeight));
        } else {
            goalWeightText.setText(R.string.goal_not_set);
        }
    }

    // when add goal weight button is clicked
    public void onAddGoalWeightClick(View view) {
        View dialogView = getLayoutInflater().inflate(R.layout.popup_new_goal, null);
        EditText goalWeightInput = dialogView.findViewById(R.id.goalWeightInput);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
                    String goalWeightStr = goalWeightInput.getText().toString();

                    if (!goalWeightStr.isEmpty()) {
                        double goalWeight = Double.parseDouble(goalWeightStr);
                        // add goal weight
                        if (db.addGoalWeight(goalWeight)) {
                            Toast.makeText(this, "Goal weight saved", Toast.LENGTH_SHORT).show();
                            onStart(); // refresh goal weight after update
                        } else {
                            Toast.makeText(this, "Error saving goal weight", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("Cancel", null).create().show();
    }

    // when add daily weight button is clicked
    public void onAddDailyWeightClick(View view) {
        View dialogView = getLayoutInflater().inflate(R.layout.popup_new_daily, null);
        EditText weightInput = dialogView.findViewById(R.id.dailyWeightInput);
        EditText dateInput = dialogView.findViewById(R.id.dailyDateInput);

        // date picker
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        // set current date
        String currentDate = new SimpleDateFormat("MM/dd/yyyy", Locale.getDefault()).format(calendar.getTime());
        dateInput.setText(currentDate);

        // show dialog picker when date is clicked
        dateInput.setOnClickListener(v -> new DatePickerDialog(WeightTrackerActivity.this, (view1, selectedYear, selectedMonth, selectedDay) -> {
            String selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%04d", selectedMonth + 1, selectedDay, selectedYear);
            dateInput.setText(selectedDate);
        }, year, month, day).show());

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView).setPositiveButton("Save", (dialog, which) -> {
            String weightStr = weightInput.getText().toString();
            String dateStr = dateInput.getText().toString();

            if (!weightStr.isEmpty() && !dateStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);
                // add new weight
                if (db.addWeight(dateStr, weight)) {
                    Toast.makeText(this, "Weight entry added", Toast.LENGTH_SHORT).show();
                    adapter.updateCursor(db.getAllWeights());
                } else {
                    Toast.makeText(this, "Error occurred when adding weight entry", Toast.LENGTH_SHORT).show();
                }
            }
        }).setNegativeButton("Cancel", null).create().show();

    }

}

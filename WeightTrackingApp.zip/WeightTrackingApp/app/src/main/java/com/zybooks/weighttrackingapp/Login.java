package com.zybooks.weighttrackingapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends Activity {

    // initialize private class variables
    private EditText usernameEditText;
    private EditText passwordEditText;
    private DatabaseLogin db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);

        db = new DatabaseLogin(this);
    }

    // Method called when login is clicked
    public void onLoginClick(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.loginUser(username, password)) {
            Intent intent = new Intent(Login.this, WeightTrackerActivity.class);
            startActivity(intent);
        } else {
            Toast.makeText(this, "Invalid username or password. Please try again.", Toast.LENGTH_SHORT).show();
        }
    }

    // register new user if register button is clicked
    public void onRegisterClick(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Please enter a username and password.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (db.registerUser(username, password)) {
            Toast.makeText(this, "Username has been registered. Please log in.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Registration unsuccessful. Username already exists.",Toast.LENGTH_SHORT).show();
        }
    }

}

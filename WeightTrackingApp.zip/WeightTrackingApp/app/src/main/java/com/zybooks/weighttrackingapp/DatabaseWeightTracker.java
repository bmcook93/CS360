package com.zybooks.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseWeightTracker extends SQLiteOpenHelper {

    // initialize static variables to create database
    private static final String DB_NAME = "weightTracker.db";
    private static final int DB_VER = 1;

    private static final String WEIGHT_TABLE = "weights";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";

    private static final String GOAL_WEIGHT_TABLE = "weight_goal";
    private static final String COLUMN_GOAL_WEIGHT = "goalWeight";

    public DatabaseWeightTracker(Context context) {
        super(context, DB_NAME, null, DB_VER);
    }

    // create table
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + WEIGHT_TABLE + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL)";
        db.execSQL(createTable);

        String createGoalWeightTable = "CREATE TABLE " + GOAL_WEIGHT_TABLE + " (" +
                COLUMN_GOAL_WEIGHT + " REAL)";
        db.execSQL(createGoalWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // unused
    }

    // add new weight record
    public boolean addWeight(String date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(WEIGHT_TABLE, null, values);
        return result != -1;
    }

    // add goal weight
    public boolean addGoalWeight(double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        // insert/update goal weight
        long result = db.insertWithOnConflict(GOAL_WEIGHT_TABLE, null, values, SQLiteDatabase.CONFLICT_REPLACE);
        return result != -1;
    }

    // get goal weight
    public double getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(GOAL_WEIGHT_TABLE, new String[]{COLUMN_GOAL_WEIGHT}, null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            // Get index of goal weight column
            int goalWeightIndex = cursor.getColumnIndex(COLUMN_GOAL_WEIGHT);

            if (goalWeightIndex != -1) {
                double goalWeight = cursor.getDouble(goalWeightIndex);
                cursor.close();
                return goalWeight;
            } else {
                cursor.close();
                return -1; // column is missing
            }
        }

        return -1; // no goal weight is found
    }

    // get all weights
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + WEIGHT_TABLE, null);
    }

    public boolean updateWeight(String oldDate, String newDate, double newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("date", newDate);
        values.put("weight", newWeight);

        int rowsAffected = db.update(WEIGHT_TABLE, values, COLUMN_DATE + " = ?", new String[]{oldDate});
        return rowsAffected > 0; // true if any rows were updated, else false
    }

    // delete weight entry
    public boolean deleteWeight(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsDeleted = db.delete(WEIGHT_TABLE, COLUMN_DATE + "=?", new String[]{date});
        return rowsDeleted > 0; // true if any rows were deleted, else false
    }
}

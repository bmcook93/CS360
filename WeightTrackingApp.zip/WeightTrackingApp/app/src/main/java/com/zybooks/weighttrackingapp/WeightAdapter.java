package com.zybooks.weighttrackingapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Locale;

// Binds database to RecyclerView
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    private final Context context;
    private Cursor cursor;
    private final DatabaseWeightTracker databaseWeightTracker;

    public WeightAdapter(Context context, Cursor cursor, DatabaseWeightTracker databaseWeightTracker) {
        this.context = context;
        this.cursor = cursor;
        this.databaseWeightTracker = databaseWeightTracker;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.weight_data, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        if (cursor.moveToPosition(position)) {
            String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow("weight"));

            holder.textViewDate.setText(context.getString(R.string.date_adapter, date));
            holder.textViewWeight.setText(context.getString(R.string.weight_adapter, weight));

            // set up delete listener
            holder.deleteButton.setOnClickListener(v -> deleteWeightEntry(date));

            // click listener for update
            holder.itemView.setOnClickListener(v -> showEditDialog(date, weight));
        }
    }

    @Override
    public int getItemCount() {
        return cursor.getCount();
    }

    @SuppressLint("NotifyDataSetChanged")
    private void deleteWeightEntry(String date) {
        boolean result = databaseWeightTracker.deleteWeight(date);

        if (result) {
            cursor = updateCursor();
            notifyDataSetChanged();

            // display toast if success
            Toast.makeText(context, "Weight entry deleted", Toast.LENGTH_SHORT).show();
        } else {
            // show toast if no deletes
            Toast.makeText(context, "Error deleting weight entry", Toast.LENGTH_SHORT).show();
        }
    }

    // update method
    @SuppressLint("NotifyDataSetChanged")
    private void showEditDialog(String currentDate, double currentWeight) {
        View dialogView = LayoutInflater.from(context).inflate(R.layout.popup_edit_weight, null);

        EditText weightInput = dialogView.findViewById(R.id.editWeightInput);
        weightInput.setText(String.valueOf(currentWeight));

        EditText dateInput = dialogView.findViewById(R.id.editDateInput);
        dateInput.setText(currentDate);

        dateInput.setOnClickListener(v -> new DatePickerDialog(context, (view, year, month, day) -> {
            String selectedDate = String.format(Locale.getDefault(), "%02d/%02d/%04d", month + 1, day, year);
            dateInput.setText(selectedDate);
        }, Integer.parseInt(currentDate.split("/")[2]),
                Integer.parseInt(currentDate.split("/")[0]) - 1,
                Integer.parseInt(currentDate.split("/")[1])).show());

        new AlertDialog.Builder(context).setTitle("Edit Weight Entry").setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newWeightStr = weightInput.getText().toString();
                    String newDate = dateInput.getText().toString();

                    if (!newWeightStr.isEmpty() && !newDate.isEmpty()) {
                        double newWeight = Double.parseDouble(newWeightStr);
                        if (databaseWeightTracker.updateWeight(currentDate, newDate, newWeight)) {
                            Toast.makeText(context, "Weight entry updated", Toast.LENGTH_SHORT).show();
                            cursor = updateCursor();
                            notifyDataSetChanged();
                        } else {
                            Toast.makeText(context, "Error updating weight entry", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("Cancel", null).create().show();
    }

    @SuppressLint("NotifyDataSetChanged")
    public Cursor updateCursor() {
        notifyDataSetChanged();
        return databaseWeightTracker.getAllWeights();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void updateCursor(Cursor newCursor) {
        if (cursor != null) {
            cursor.close();
        }
        cursor = newCursor;
        notifyDataSetChanged();
    }

    public static class WeightViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewDate, textViewWeight;
        public Button deleteButton;

        public WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewWeight = itemView.findViewById(R.id.textViewWeight);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}
